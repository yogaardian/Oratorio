import React from 'react';
import './header-guide.css';

// Komponen Header ini bisa kita beri 'props' (properti)
// seperti 'title' untuk menampilkan judul halaman yang sedang aktif.
function Header({ pageTitle }) {
  return (
    <header className="site-header">
      <div className="header-container">
        {/* Bagian Kiri: Logo */}
        <a href="/" className="header-brand">ORATORIO</a>

        {/* Bagian Tengah: Judul Halaman (dinamis) */}
        {pageTitle && <h1 className="header-page-title">{pageTitle}</h1>}

        {/* Bagian Kanan: Link kembali atau ikon profil */}
        <div className="header-right">
          <a href="/" className="header-link">Kembali ke Home</a>
        </div>
      </div>
    </header>
  );
}

export default Header;
