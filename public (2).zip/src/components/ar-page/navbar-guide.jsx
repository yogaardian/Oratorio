// components/all-page/ar-page/navbar-guide.jsx
import React from 'react';
import './navbar-guide.css';
import imgTugu from '../../assets/images/fav-dest-section-tugu-jogja.jpg';
import imgJamGadang from '../../assets/images/fav-dest-section-jam-gadang.jpg';

const ARNavbar = ({ currentSlide = 0, onSlideChange = () => {} }) => {
  const slides = [
    {
      id: 1,
      title: 'Hadirkan Dunia Virtual ke Ruangan',
      subtitle: 'Anda Dengan Augmented Reality',
      description: 'Ikuti 3 Langkah Mudah di Bawah ini untuk Memulai Petualangan Anda',
      image: imgTugu,
      type: 'intro'
    },
    {
      id: 2, 
      title: 'Unduh QR TORIO',
      subtitle: '',
      description: '',
      image: imgJamGadang,
      type: 'qr'
    }
  ];

  const safeCurrentSlide = Math.max(0, Math.min(currentSlide, slides.length - 1));
  const currentSlideData = slides[safeCurrentSlide];

  if (!currentSlideData) {
    return <div>Error: Slide tidak ditemukan</div>;
  }

  return (
    <div className="ar-navbar">
      {/* Navigation Arrows */}
      <div className="nav-arrows">
        <button 
          className={`arrow-btn prev-btn ${safeCurrentSlide === 0 ? 'disabled' : ''}`}
          onClick={() => onSlideChange(safeCurrentSlide - 1)}
          disabled={safeCurrentSlide === 0}
        >
          ‹
        </button>

        <div className="slide-indicator">
          <span>{safeCurrentSlide + 1}</span>
          <div className="divider-line"></div>
          <span>{slides.length}</span>
        </div>

        <button 
          className={`arrow-btn next-btn ${safeCurrentSlide === slides.length - 1 ? 'disabled' : ''}`}
          onClick={() => onSlideChange(safeCurrentSlide + 1)}
          disabled={safeCurrentSlide === slides.length - 1}
        >
          ›
        </button>
      </div>

      {/* Slide Content */}
      <div className="slide-content">
        {/* Text Content */}
        <div className="text-content">
          <h1 className="slide-title">
            {currentSlideData.title}
          </h1>
          
          {currentSlideData.subtitle && (
            <h2 className="slide-subtitle">
              {currentSlideData.subtitle}
            </h2>
          )}

          {currentSlideData.type === 'intro' && (
            <>
              <div className="title-divider"></div>
              <p className="slide-description">
                Ikuti 3 Langkah Mudah di Bawah ini untuk Memulai<br />
                Petualangan Anda
              </p>
            </>
          )}
        </div>

        {/* Image Content */}
        <div className="image-content">
          <img 
            src={currentSlideData.image} 
            alt={currentSlideData.type === 'intro' ? 'Tugu Jogja' : 'Jam Gadang'} 
            className="slide-image"
          />
          {currentSlideData.type === 'qr' && (
            <div className="qr-overlay">
              <div className="qr-badge">QR Code Ready</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ARNavbar;