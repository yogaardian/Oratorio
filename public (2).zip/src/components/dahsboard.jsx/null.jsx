import React from "react";

<section>
    <div class="kosong">
aaa
  </div>
</section>
