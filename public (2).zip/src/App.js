import React from 'react';
import './App.css';
import './index'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

// Import semua halaman yang akan digunakan
import LandingPage from './pages/landing_page'; // Halaman ini sudah berisi Navbar & Hero
import LoginPage from './pages/login';
import RegisterPage from './pages/register';
import Dashboard from './pages/dashboard';
import ARPage from './components/ar-page/navbar-guide';

function App() {
  return (

    <Router>
      <div className="App">
        <Routes>
          {/* Saat user di '/', tampilkan seluruh komponen LandingPage */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/ar-page" element={<ARPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;