// components/all-page/ar-page/ARPage.js
import React, { useState } from 'react';
import ARNavbar from './navbar-guide';
import Footer from '../footer-page/footer'; 

const ARPage = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const handleSlideChange = (newSlide) => {
    // Pastikan newSlide valid
    if (newSlide >= 0 && newSlide <= 1) { // 0 dan 1 untuk 2 slide
      setCurrentSlide(newSlide);
    }
  };

  return (
    <div className="ar-page">
      <ARNavbar 
        currentSlide={currentSlide} 
        onSlideChange={handleSlideChange} 
      />
      <Footer />
    </div>
  );
};

export default ARPage;