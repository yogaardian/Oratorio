import React, { useState, useEffect } from "react";
import "./header.css";
import { FaSun, FaMoon } from "react-icons/fa";

function Header() {
  const [darkMode, setDarkMode] = useState(false);

  // Simpan preferensi user agar tetap bertahan saat reload
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
      document.body.classList.add("dark-theme");
      setDarkMode(true);
    }
  }, []);

  const toggleTheme = () => {
    const isDark = !darkMode;
    setDarkMode(isDark);

    if (isDark) {
      document.body.classList.add("dark-theme");
      localStorage.setItem("theme", "dark");
    } else {
      document.body.classList.remove("dark-theme");
      localStorage.setItem("theme", "light");
    }
  };

  return (
    <header className="site-header">
      <div className="header-container">
        <a href="/" className="header-brand">ORATORIO</a>

        <nav className="header-center">
          <a href="#home" className="header-link">Home</a>
          <a href="#about" className="header-link">About</a>
          <a href="#history" className="header-link">History</a>
        </nav>

        <button className="theme-toggle" onClick={toggleTheme}>
          {darkMode ? <FaSun className="sun-icon" /> : <FaMoon className="moon-icon" />}
        </button>
      </div>
    </header>
  );
}

export default Header;
