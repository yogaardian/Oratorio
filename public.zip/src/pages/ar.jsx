import React from 'react';

function About() {
    return (
        <div className="About-container">
            <h1>About Us</h1>
            <p>Welcome to the About Us page!</p>
        </div>
    );
}

export default About;
