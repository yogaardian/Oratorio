import React from 'react';
import './App.css';
import './index'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { ThemeProvider } from "./context/themecontext";

// Import semua halaman yang akan digunakan
import LandingPage from './pages/landing_page'; // Halaman ini sudah berisi Navbar & Hero
import LoginPage from './pages/login';
import RegisterPage from './pages/register';

function App() {
  return (
    <ThemeProvider>
    <Router>
      <div className="App">
        <Routes>
          {/* Saat user di '/', tampilkan seluruh komponen LandingPage */}
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Routes>
      </div>
    </Router>
    </ThemeProvider>
  );
}

export default App;